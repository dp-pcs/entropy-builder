# Universal Baseline
**What every second brain needs, regardless of role or domain**

---

## The Seven Non-Negotiables

Every brain — Sales, Product, Engineering, AI CoE, Finance, HR, whatever
the role — must have these seven things. No exceptions.

The *content* is domain-specific. The *structure* is universal.

---

### 1. Profile (`[Name]-Profile.md`)

Who you are as a professional and decision-maker.

**Must contain:**
- Operating style (how you think, decide, and communicate)
- Psychological profile if available (MBTI, DiSC, CliftonStrengths, etc.)
- 3 spiky POVs — non-negotiable beliefs you'd argue for
- 2–3 genuine strengths (specific, not generic)
- 1–2 growth edges (what you're actively working on)
- Working style (remote/office, collaboration preferences, timezone)

**If they don't have a psych profile:**
Offer these free options before continuing:
- 16Personalities (MBTI-adjacent, 15 min): https://www.16personalities.com
- HIGH5 Strengths (CliftonStrengths alternative, free): https://high5test.com
- Crystal Knows (personality from LinkedIn, free tier): https://crystalknows.com
- Big Five (most empirically grounded, free): https://www.truity.com/test/big-five-personality-test

Say: "A psych profile makes your Profile.md significantly more useful —
it gives your AI agent a model for how you think under pressure. Takes
15 minutes. Want the link, or skip for now?"

Don't block on it. Note it as a gap if they skip.

---

### 2. Rules (`CLAUDE.md`)

Operating boundaries — what you can decide, what requires approval,
what you'd never do without sign-off.

**Must contain:**
- Decision authority (what you own autonomously vs. what needs approval)
- Hard limits (things you'd never do without explicit sign-off)
- Data sensitivity (what's private vs. shareable)

**Domain-specific prompts:**
- Sales/CS: pricing authority, discount tiers, what you can promise customers
- Product/Eng: what you can commit to ship, resource authority
- Marketing: spend authority, what requires legal/brand review
- Leadership: hiring authority, budget authority, public commitment authority
- AI/Architecture: what you can deploy or approve without review,
  data governance constraints
- Any role: escalation triggers, approval chains, ethical limits

---

### 3. Decision-Making Framework (`frameworks/Decision-Making-Framework.md`)

How they actually make decisions — not theory, their real process.

**Must contain:**
- How they categorize decisions (high stakes vs. reversible vs. time-sensitive)
- Their process for each type
- How they handle decisions under uncertainty or incomplete information
- Their bias awareness (what they know they over/under-weight)
- A real example

**Key interview question:**
"Walk me through a significant decision you made in the last 3 months.
What was your process? What almost made you decide differently?"

---

### 4. Communication Framework (`frameworks/Communication-Framework.md`)

How they structure and deliver thinking to others.

**Must contain:**
- How they structure arguments (bottom-up, top-down, data-first, story-first)
- How they adapt for different audiences (executive, peer, report, client)
- Their go-to format for written communication
- How they handle disagreement or pushback
- A real example

**Key interview question:**
"What's a message you've delivered that landed really well?
What made it work?"

---

### 5. Learning System (`frameworks/Learning-System.md`)

How they acquire, process, and retain new knowledge.

**Must contain:**
- How they decide what's worth learning (filter criteria)
- Their intake process (how do they read/watch/listen?)
- How they consolidate (notes, discussion, application?)
- How they know something has actually changed how they work
- Current active learning (what are they working on right now?)

**Key interview question:**
"What's the last thing you learned that actually changed how you work?
How did you learn it and how did you apply it?"

---

### 6. Domain MOC (`mocs/[Domain]-MOC.md`)

A navigation hub for their primary domain of expertise.

Every person has at least one domain they know better than most.
This MOC clusters everything related to it.

**Examples by role:**
- Sales: Enterprise Sales MOC, Renewal Strategy MOC
- Product: Roadmap Planning MOC, User Research MOC
- Engineering: Architecture MOC, Systems Design MOC
- AI/CoE: AI Strategy MOC, Adoption & Governance MOC
- Marketing: Campaign Planning MOC, Buyer Intelligence MOC
- CS: Account Health MOC, Escalation Management MOC
- Leadership: Strategic Planning MOC, Org Design MOC

**Key interview question:**
"If you had to organize everything you know professionally into
3–4 buckets, what would they be?"

Those buckets are the MOCs.

---

### 7. TRAVERSAL-INDEX (`TRAVERSAL-INDEX.md`)

Master index of all files. Written last, after everything else exists.
Format per `spec/ontology.md`.

---

## Domain-Specific Frameworks (Additive)

After the seven universals are covered, add 2–4 domain-specific frameworks
extracted from the interview or scan. These are NOT prescriptive — they come
from what the person actually does, not from a template list.

**How to identify them:**
Ask: "What are the 3 most common high-stakes situations in your role?
Walk me through how you handle each one."

Each answer that has a repeatable process → becomes a framework file.

**Examples of what surfaces by domain:**
- Sales: negotiation, account planning, renewal, expansion
- Product: prioritization, roadmap planning, user research synthesis
- Engineering/Architecture: design review process, build-vs-buy decision,
  technical debt triage
- AI CoE: AI use case evaluation, adoption playbook, governance model,
  vendor/model selection
- Marketing: campaign planning, content strategy, attribution model
- CS/Success: health scoring, escalation management, QBR structure
- Leadership: RACI, hiring criteria, performance management

The builder does NOT prescribe these. It extracts them through
conversation or scan, then generates files from real answers.

---

## Minimum Viable Brain (What "Done" Looks Like for Phase 1)

A brain is functional when it has:

| Item | Minimum |
|------|---------|
| Profile | Complete with spiky POVs |
| CLAUDE.md | Approval matrix filled in |
| Universal frameworks | All 3 (Decision, Communication, Learning) |
| Domain frameworks | At least 2, from their actual work |
| Sources | At least 3, with how each changed their behavior |
| People/mentors | At least 1 |
| MOCs | At least 2, with wikilinks populated |
| TRAVERSAL-INDEX | All files listed |

**Total target: 15–30 files.** Not 200. Not 5.
A well-connected 20-node brain beats a hollow 100-node dump every time.
