# File Scanner
**Instructions for Claude Code on directory scanning, classification, and ingestion**

---

## When to Use This

Scenario 3 only — user has no organized second brain and no OPML export.
Instead of asking them to find documents manually, ask for directory paths
and scan on their behalf.

---

## Step 1: Get the Paths

Ask:
"Tell me up to 5 directory paths you actually use for work.
For example:
  ~/Documents
  ~/Desktop
  ~/Downloads
  ~/Dropbox/Work
  ~/Google Drive/My Drive
  ~/OneDrive/Documents

Just the paths — I'll do the rest."

Accept whatever they give. Don't require 5. Even one directory is enough
to start.

Also ask:
"Are there any folders I should skip? (personal finances, photos,
anything not work-related)"

Add those to an exclusion list.

---

## Step 2: Run the Scan

Use bash to scan each directory. Do this silently — don't narrate the
commands, just run them and report the findings.

### Files to look for

```bash
# Documents and notes (last 180 days, active content)
find [path] -type f \( \
  -name "*.md" -o \
  -name "*.txt" -o \
  -name "*.docx" -o \
  -name "*.doc" \
\) -not -path "*/node_modules/*" \
   -not -path "*/.git/*" \
   -not -path "*/archive/*" \
   -not -path "*/old/*" \
   2>/dev/null | head -100

# Presentations (often contain frameworks and structured thinking)
find [path] -type f \( \
  -name "*.pptx" -o \
  -name "*.key" -o \
  -name "*.pdf" \
\) -not -path "*/receipts/*" \
   -not -path "*/invoices/*" \
   2>/dev/null | head -50

# Notes exports
find [path] -type f \( \
  -name "*.opml" -o \
  -name "*.enex" -o \
  -name "*.json" \
\) 2>/dev/null | head -20
```

### Recency filter
Prioritize files modified in the last 180 days. Files older than 2 years
are low priority unless the filename suggests it's foundational (e.g.
"principles", "philosophy", "framework", "playbook", "strategy").

---

## Step 3: Read and Classify

For each candidate file, read enough of the content to classify it.
For large files (>50KB), read the first 200 lines only.

Classify into these buckets:

| Bucket | What it looks like | Maps to |
|--------|-------------------|---------|
| **Framework candidate** | A process, methodology, step-by-step approach, playbook, how-to | `framework` |
| **Strategy/principles** | Beliefs, operating principles, philosophy, manifesto | `profile` or `framework` |
| **Reference material** | Product docs, technical specs, policy docs, how things work | `documentation` |
| **Reading/learning** | Book notes, course notes, summaries, annotated PDFs | `source` |
| **Case/example** | War stories, project retrospectives, lessons learned, win/loss | `case` |
| **People/influence** | Notes about a mentor, person profile, bio, influence notes | `person` |
| **Junk** | Receipts, meeting logistics, random notes, unrelated personal | skip |
| **Uncertain** | Can't tell from first 200 lines | flag for user |

---

## Step 4: Present the Shortlist

Do NOT present every file found. Surface only the most promising candidates.
Cap at 20 files maximum. Quality over completeness.

Format:

```
I scanned [N] files across your directories. Here's what looks useful:

FRAMEWORKS / PROCESSES
  [1] ~/Documents/AI-Strategy-2025.pptx
      "AI adoption framework for enterprise..." (looks like a strategy doc)
  [2] ~/Documents/Architecture-Principles.md
      "We believe systems should be..." (structured principles)

REFERENCE MATERIAL
  [3] ~/Documents/vendor-evals/Shortlist-2025.docx
      Vendor evaluation criteria and scoring

SOURCES / READING NOTES
  [4] ~/Downloads/atomic-habits-notes.md
      Book notes, behavioral change frameworks
  [5] ~/Documents/Team-Retros/Q1-2025.md
      Retrospective with lessons learned

UNCERTAIN — I'M NOT SURE WHAT THESE ARE
  [6] ~/Desktop/notes.txt
      Short file, unclear topic — want me to include it?

SKIPPED (not work-relevant)
  - 23 PDF receipts in ~/Downloads
  - 8 personal finance spreadsheets
  - 14 photo files

Which of these should I include in your brain?
Reply with numbers (e.g. "1, 2, 4"), "all", or tell me what to skip.
```

---

## Step 5: Ingest Confirmed Files

For each file the user confirms:

1. Read the full content (up to 500 lines for large files)
2. Extract the signal:
   - For frameworks: the actual steps/process described
   - For principles: the stated beliefs
   - For reading notes: key ideas and how they were applied
   - For cases: what happened, what was decided, what was learned
3. Generate a proper brain file using the appropriate template
   from `templates/`
4. Add a NEEDS REVIEW comment at the top of each imported file:
   `<!-- IMPORTED from [original path] — review and edit to match
   how you actually work today -->`
5. Don't copy content verbatim — synthesize it into the correct
   template structure. The goal is a well-formed brain node, not
   a document dump.

---

## Step 6: Gap Analysis

After ingesting confirmed files, compare coverage against the universal
baseline:

**Everyone needs these — check if covered:**
- [ ] Profile (identity, operating style, spiky POVs)
- [ ] CLAUDE.md (decision authority, limits, approval chains)
- [ ] At least 1 Decision-Making Framework
- [ ] At least 1 Communication Framework
- [ ] At least 3 sources
- [ ] At least 1 person/mentor
- [ ] At least 2 MOCs

**Report gaps clearly:**
"I found good content for [X, Y, Z]. Still missing:
  - Your profile (I'll get this from the interview)
  - A decision-making framework (didn't find one in your files)
  - Sources / reading influences

I'll get these through a few targeted questions now."

Then run ONLY the interview sections needed to fill the gaps.
Don't re-ask for things the scan already surfaced.

---

## What NOT to Do

- Don't scan system directories (/usr, /bin, /Library, /System)
- Don't read files larger than 5MB
- Don't ingest anything in folders named: personal, private, finance,
  taxes, legal, health, family, photos, videos, music
- Don't surface files with names suggesting sensitive content:
  salary, compensation, SSN, passport, medical, therapy
- Don't present more than 20 candidates — curate ruthlessly
- Don't copy-paste raw document content into brain files — always
  reformat into the template structure
